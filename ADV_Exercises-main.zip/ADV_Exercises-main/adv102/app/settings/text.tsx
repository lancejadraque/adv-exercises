import { View, Text } from "react-native";

export default function Test(){

    return (
        <View>
            <Text>
                http://localhost:8081/settings/test
            </Text>
        </View>
    )
}