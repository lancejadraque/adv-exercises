import { View, Text } from "react-native";

export default function Settings(){

    return (
        <View>
            <Text>
                http://localhost:8081/settings
            </Text>
        </View>
    )
}