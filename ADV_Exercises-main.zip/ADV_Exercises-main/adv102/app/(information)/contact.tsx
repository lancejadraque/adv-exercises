import { View, Text } from "react-native";

export default function Contact(){

    return (
        <View>
            <Text>Contact</Text>
        </View>
    )
}