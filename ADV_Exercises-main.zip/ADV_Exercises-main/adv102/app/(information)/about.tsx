import { View, Text } from "react-native";

export default function About(){

    return (
        <View>
            <Text>About</Text>
        </View>
    )
}