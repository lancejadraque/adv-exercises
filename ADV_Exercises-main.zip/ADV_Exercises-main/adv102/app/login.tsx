import { View, Text } from "react-native";

export default function Login() {
    return (
        <View>
            <Text>Login</Text>
        </View>
    )
}