import HomeScreen from './Screens/HomeScreen';

import {Text} from 'react-native';

function App() {
    return <HomeScreen />;

}

export default App;